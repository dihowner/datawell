<?php

namespace App\Http\Controllers;

use App\Models\ProductPricing;
use Illuminate\Http\Request;

class ProductPricingController extends Controller
{
    public function setProductPrid()
    {
        # code...
    }
}