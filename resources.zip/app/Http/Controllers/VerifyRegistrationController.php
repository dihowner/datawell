<?php

namespace App\Http\Controllers;

use App\Models\VerifyRegistration;
use Illuminate\Http\Request;

class VerifyRegistrationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\VerifyRegistration  $verifyRegistration
     * @return \Illuminate\Http\Response
     */
    public function show(VerifyRegistration $verifyRegistration)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\VerifyRegistration  $verifyRegistration
     * @return \Illuminate\Http\Response
     */
    public function edit(VerifyRegistration $verifyRegistration)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\VerifyRegistration  $verifyRegistration
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, VerifyRegistration $verifyRegistration)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\VerifyRegistration  $verifyRegistration
     * @return \Illuminate\Http\Response
     */
    public function destroy(VerifyRegistration $verifyRegistration)
    {
        //
    }
}
