<?php

namespace App\Http\Controllers;

use App\Services\WalletService;
use App\Vendors\MobileNig;
use App\Vendors\Smeplug;
use Illuminate\Http\Request;

class TestController extends Controller
{

    // public function fetchService() {
    //     return app(WalletService::class)->walletCredited('this_month');
    //     // return 1111;
    // }

    public function fetchService() {
        return app(MobileNig::class)->getService('BCC', 'GIFTING', 'pk_live_UJCy9EP/EQgKl54XGY+FNCnuAeHuUt5Oofb5CUtUIy4=');
        return [];
    }

    public function fetchSmeplugDataService() {
        return app(Smeplug::class)->getDataService('31bf3792b4b642cb7449f1499b4b90fa6cfbad6875a6d2322af7550e931fa70e');
        return [];
    }
}
