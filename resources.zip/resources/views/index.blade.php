 <script>
    // Replace the URL below with the desired destination URL
    var destinationUrl = 'http://peaktopup.com';
    
    // Redirect the user to the specified URL
    window.location.href = destinationUrl;
</script>