

<div class="page-header">
    <div class="page-leftheader">
        <h4 class="page-title">Welcome <strong class="text-danger">{{ $adminUser->fullname }}! </strong>
            ({{ $adminUser->roles->role_type }})
        </h4>
        <em class="fs-20">...making data cheaper and affordable.</em>
    </div>
</div>