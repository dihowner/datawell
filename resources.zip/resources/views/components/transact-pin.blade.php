<label for="amount" class="form-label">Transaction Pin:</label>
<input class="form-control form-control-lg transactPin" name="transactpin" placeholder="Enter transaction pin"
    type="password" maxlength="4">
